/* 
 * File:   funciones.c
 * Author: Jose Miguel Espinoza Mestanza
 *
 * Created on 20 de noviembre de 2021, 08:55 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "funciones.h"
#define num_var 10
#define num_iter 1000
#define cool_down 5
#define dist_max 100
#include <time.h>

void inicializar_sol(int*arr_sol){
    arr_sol[0]= 0;
    arr_sol[1]= 1;
    arr_sol[2]= 2;
    arr_sol[3]= 3;
    arr_sol[4]= 4;
    arr_sol[5]= 5;
    arr_sol[6]= 6;
    arr_sol[7]= 7;
    arr_sol[8]= 8;
    arr_sol[9]= 9;
    arr_sol[10]= 0;
}
void registrar_distancias(int mat_distancias[num_var][num_var]){
    printf("Matriz de distancias: \n");
    int distancia;
    int i, j, espacios;
    for(i=0; i<num_var-1;i++){
        for(espacios=i*7;espacios>=0;espacios--)printf(" ");
        for(j=i+1; j<num_var; j++){
            distancia=rand()%dist_max;
            if(distancia==0)j--;
            else {
                mat_distancias[i][j]=distancia;
                printf(" %3d - ", mat_distancias[i][j]);
            }
        }
        printf("\n");
        
    }
}
void inicializar_mem(int mat_memoria[num_var][num_var]){
    for(int i=0; i<num_var;i++){
        for(int j=0; j<num_var;j++)
            mat_memoria[i][j]=0;
    }
}
void imprimir_sol(int*arr_sol, int tiempo){
    printf("Solución obtenida:\n");
    for(int i=0; i<num_var+1;i++)
        printf(" %3d -", arr_sol[i]);
    printf(" Distancia del recorrido: %d \n", tiempo);
}
void inicializar_top(int mat_top_5[][num_var+2]){
    for(int i=0; i<5;i++)mat_top_5[i][num_var+1]=dist_max*num_var;
}
void realizar_met_tabu(int *sol_actual,int mat_distancias[][num_var], 
        int mat_top_5[][num_var+2],int mat_memoria[][num_var]){
    int distancia1, distancia2;
    int pos1, pos2;
    for(int i=0; i<num_iter;i++){
        asignar_random(&pos1, &pos2);//pos1 != pos 2 y no pueden ser extremos
        if(cambio_permitido(mat_memoria, pos1, pos2)){
            distancia1=funcion_valor(sol_actual, mat_distancias);//valor de la solucion actual
            realizar_cambio(sol_actual, pos1, pos2);
            distancia2=funcion_valor(sol_actual, mat_distancias);//valor de la nueva solución
            anotar_cambio(mat_memoria, pos1, pos2);
            if(distancia1<=distancia2)//si la nueva sol no es mejor que la anterior
               realizar_cambio(sol_actual, pos1, pos2);//se revierte el cambio realizado
            else anotar_top_5(mat_top_5, sol_actual, distancia2,mat_memoria[pos2][pos1]);
                
            desc_mem_corta(mat_memoria);
        }
        
    }
}
void asignar_random(int*pos1, int*pos2){
    int a,b;
    while(1){
        a=rand()%num_var;
        b=rand()%num_var;
        if(a!=b && validar_extremos(a, b))break;
    }
    (*pos1)=a;
    (*pos2)=b;
}
int cambio_permitido(int mem_corta[num_var][num_var],int fila,int columna){
    if(mem_corta[fila][columna]==0){
        mem_corta[fila][columna]=cool_down;
        
        return 1;
    }
    else return 0;
}
int validar_extremos(int fila, int columna){
    if(fila==0 || fila == num_var)return 0;
    if(columna==0 || columna == num_var)return 0;
    return 1;
}
int funcion_valor(int*sol_actual, int mat_distancias[][num_var]){
    int valor=0, pos=0, i, j;
    while(1){
        i=sol_actual[pos];
        j=sol_actual[pos+1];
        if(i>j)valor+=mat_distancias[j][i];
        else valor+=mat_distancias[i][j];
        pos++;
        if(j==0)return valor;
    }
}
void realizar_cambio(int*arr_sol, int pos1, int pos2){
    int aux;
    aux=arr_sol[pos1];
    arr_sol[pos1]=arr_sol[pos2];
    arr_sol[pos2]=aux;
}
void anotar_cambio(int mem_larga[num_var][num_var], int columna, int fila){
    mem_larga[fila][columna]++;
}
void anotar_top_5(int mat_top_5[][num_var+2], int*sol_actual, int distancia_sol, int penalizacion){
    int i, j, solucion_penalizada;
    solucion_penalizada=penalizar(distancia_sol, penalizacion);
    for(i=0; i<5;i++){
        if(solucion_penalizada<mat_top_5[i][num_var+1]){
            for(j=0; j<num_var+1;j++){
                mat_top_5[i][j]=sol_actual[j];
            }
            mat_top_5[i][num_var+1]=distancia_sol;
        }
    }
}
void desc_mem_corta(int mat_memoria[][num_var]){
    for(int i=0; i<num_var-1; i++){
        for(int j=i+1;j<num_var;j++){
            if(mat_memoria[i][j]>0)
                mat_memoria[i][j]--;
        }
    }
}
int penalizar(int dist_sol, int penalizacion){
    return dist_sol+10*penalizacion;
}