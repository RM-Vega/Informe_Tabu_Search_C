/* 
 * File:   main.c
 * Author: Jose Miguel Espinoza Mestanza
 *
 * Created on 20 de noviembre de 2021, 08:54 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "funciones.h"
#define num_var 10
int main(int argc, char** argv) {
    
    int sol_actual[num_var+1], mat_distancias[num_var][num_var];
    int mat_top_5[5][num_var+2], mat_memoria[num_var][num_var];
    inicializar_sol(sol_actual);
    registrar_distancias(mat_distancias);
    inicializar_mem(mat_memoria);
    imprimir_sol(sol_actual, funcion_valor(sol_actual, mat_distancias));
    inicializar_top(mat_top_5);
    realizar_met_tabu(sol_actual,mat_distancias,mat_top_5, mat_memoria);
    imprimir_sol(mat_top_5[0], mat_top_5[0][num_var+1]);
    return (EXIT_SUCCESS);
}

