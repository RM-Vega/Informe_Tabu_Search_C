/* 
 * File:   funciones.h
 * Author: Jose Miguel Espinoza Mestanza
 *
 * Created on 20 de noviembre de 2021, 08:55 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#define num_var 10
void inicializar_sol(int*);
void registrar_distancias(int mat_distancias[][num_var]);
void inicializar_mem(int mat_memoria[][num_var]);
void imprimir_sol(int*, int);
void inicializar_top(int mat_top_5[][num_var+2]);
void realizar_met_tabu(int *sol_actual,int mat_distancias[][num_var], 
        int mat_top_5[][num_var+2],int mat_memoria[][num_var]);
void asignar_random(int*, int*);
int cambio_permitido(int mem_corta[][num_var],int ,int );
int validar_extremos(int fila, int columna);
int funcion_valor(int*, int mat_distancias[][num_var]);
void realizar_cambio(int*, int , int );
void anotar_cambio(int mem_larga[][num_var], int , int );
void anotar_top_5(int mat_top_5[][num_var+2], int*sol_actual, int dist_sol, int penalizacion);
void desc_mem_corta(int mat_memoria[][num_var]);
void penalizar_memoria_larga(int*sol, int mat_top_5[][num_var+2],
        int mat_memoria[][num_var]);
int penalizar(int dist_sol, int penalizacion);
#endif /* FUNCIONES_H */

